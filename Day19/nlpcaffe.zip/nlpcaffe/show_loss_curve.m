clear;
clc;
close all;

fid = fopen('matlab_train_loss', 'r');
train_loss = fscanf(fid, '%f\n');
fclose(fid);
n = 1:length(train_loss);
idx_train = (n - 1) * 100;

fid = fopen('matlab_test_loss', 'r');
test_loss = fscanf(fid, '%f\n');
fclose(fid);
m = 1:length(test_loss);
idx_test = (m - 1) * 1000;
figure;plot(idx_train, train_loss);
hold on;
plot(idx_test, test_loss);

grid on;
legend('Train Loss', 'Test Loss');
xlabel('iterations');
ylabel('loss');
title(' Train & Test Loss Curve');
